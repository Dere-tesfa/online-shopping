

/**
 * @author Tadios
 * @version 1.0
 * @created 11-Nov-2025 10:00:00 AM
 */
public class product {

	public double price;
	public int product_id;
	public string product_name;
	public shoppingcart m_shoppingcart;
	public paymeent m_paymeent;
	public order m_order;

	public product(){

	}

	public void finalize() throws Throwable {

	}

	public void show_detail(){

	}

}