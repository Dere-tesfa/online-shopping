

/**
 * @author Tadios
 * @version 1.0
 * @created 11-Nov-2025 10:00:00 AM
 */
public class user {

	public string email;
	public string name;
	private int user_id;
	public product m_product;
	public shoppingcart m_shoppingcart;
	public paymeent m_paymeent;

	public user(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param password
	 * @param email
	 */
	public void login(string password, string email){

	}

	/**
	 * 
	 * @param password
	 * @param name
	 * @param email
	 */
	public void register(string password, string name, string email){

	}

}