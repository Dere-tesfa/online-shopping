

/**
 * @author Tadios
 * @version 1.0
 * @created 11-Nov-2025 10:00:00 AM
 */
public class order {

	protected int order_date;
	private int order_id;
	public user m_user;
	public paymeent m_paymeent;

	public order(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param product
	 */
	public void track_order(string product){

	}

	public void view_product(){

	}

}