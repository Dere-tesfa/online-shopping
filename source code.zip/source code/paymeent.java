

/**
 * @author Tadios
 * @version 1.0
 * @created 11-Nov-2025 10:00:00 AM
 */
public class paymeent {

	private int payment_id;
	protected string payment_method;

	public paymeent(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param amount
	 */
	public void pay(double amount){

	}

}