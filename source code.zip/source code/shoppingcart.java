

/**
 * @author Tadios
 * @version 1.0
 * @created 11-Nov-2025 10:00:00 AM
 */
public class shoppingcart {

	protected string cart_id;
	public int created_date;
	public string product;

	public shoppingcart(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param product
	 */
	public void addProduct(string product){

	}

	public void checkout(){

	}

	/**
	 * 
	 * @param product
	 */
	public void removeProduct(string product){

	}

}